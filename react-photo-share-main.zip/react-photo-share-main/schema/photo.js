"use strict";

const mongoose = require("mongoose");

/**
 * Mongoose Schema definition for a Comment.
 */
const commentSchema = new mongoose.Schema({
  // Text content of the comment.
  comment: String,
  // Date and time when the comment was created (defaults to the current date and time).
  date_time: { type: Date, default: Date.now },
  // ID of the user associated with the comment.
  user_id: mongoose.Schema.Types.ObjectId,
  // Unique ID for the comment.
  comment_id: mongoose.Schema.Types.ObjectId,
});

/**
 * Mongoose Schema definition for a Photo.
 */
const photoSchema = new mongoose.Schema({
  // File name of the photo (located in the project6/images directory).
  file_name: String,
  // Date and time when the photo was added to the database (defaults to the current date and time).
  date_time: { type: Date, default: Date.now },
  // ID of the user who created the photo.
  user_id: mongoose.Schema.Types.ObjectId,
  // Array of comment objects representing comments made on this photo.
  comments: [commentSchema],
  // Count of comments on the photo.
  commentCount: { type: Number, default: 0 },
  // List of users with whom the photo is shared.
  sharingList: [String],
  // Flag indicating whether the photo is private (only visible to the owner).
  isPrivate: Boolean,
});

/**
 * Mongoose Model for a Photo using the photoSchema.
 */
const Photo = mongoose.model("Photo", photoSchema);

/**
 * Export the Photo model for use in the application.
 */
module.exports = Photo;
