"use strict";

const mongoose = require('mongoose');

/**
 * Define a Mongoose Schema for schema information.
 * It includes fields for version and load date time.
 */
const schemaInfo = new mongoose.Schema({
    version: String,
    load_date_time: {type: Date, default: Date.now},
});

/**
 * Create a Mongoose Model for schema information using the defined schema.
 * This model is named 'SchemaInfo'.
 */
const SchemaInfo = mongoose.model('SchemaInfo', schemaInfo);

/**
 * Export the SchemaInfo model to make it accessible in our application.
 */
module.exports = SchemaInfo;
